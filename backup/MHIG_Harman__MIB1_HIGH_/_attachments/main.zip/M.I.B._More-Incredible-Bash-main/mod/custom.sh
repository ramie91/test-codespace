#!/bin/sh
# copy into /mod/ on M.I.B. SD

echo "custom.sh is running - " # put here some information about the custom.sh

# put commands here...

echo "!!!  all done  !!!"